package JavaBasico;

public class MinhaClasse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Olá sejam bem vindos ao meu git de Java");

	}

}
