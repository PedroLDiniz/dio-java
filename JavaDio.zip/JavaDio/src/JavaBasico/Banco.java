package JavaBasico;

import java.util.Scanner;

public class Banco {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		double saldo = 25;
		
		double valorSolicitado = 18;
		
		if (saldo > valorSolicitado) {
			saldo = saldo - valorSolicitado;
		}
		else
			System.out.println("Valor Insuficiente");
		
		
		System.out.println(" Saldo de : R$" + saldo);
		
	}

}
