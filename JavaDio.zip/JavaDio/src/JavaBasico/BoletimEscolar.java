package JavaBasico;

public class BoletimEscolar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int mediaFinal = 6;
		if (mediaFinal > 6) {
			System.out.println("Aprovado");
			
		}
		else if (mediaFinal == 6) {
			System.out.println("Exame");
			
		}
		else 
			System.out.println("Reprovado");

	}

}
